import pygame
from environment import build_environment
from ui_dashboard import Dashboard

def main():
    pygame.init()
    pygame.display.set_caption("Robot Vacuum Simulation - Independent Control")

    W, H = 1400, 860
    screen = pygame.display.set_mode((W, H))
    clock = pygame.time.Clock()

    fonts = {
        "title": pygame.font.SysFont("Arial", 26, bold=True),
        "h2": pygame.font.SysFont("Arial", 18, bold=True),
        "small": pygame.font.SysFont("Arial", 14),
    }

    map_grid, start_rc = build_environment()
    dashboard = Dashboard(fonts, map_grid, start_rc)

    running = True
    while running:
        dt = clock.tick(60) / 1000.0

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                running = False
            dashboard.handle_event(event)

        dashboard.update(dt)
        dashboard.draw(screen, W, H)
        pygame.display.flip()

    pygame.quit()

if __name__ == "__main__":
    main()

import numpy as np

class MapGrid:

    def __init__(self, width_m=12.0, height_m=9.0, cell_size=0.2):
        self.cell_size = float(cell_size)
        self.ncols = int(round(width_m / self.cell_size))
        self.nrows = int(round(height_m / self.cell_size))
        self.grid = np.zeros((self.nrows, self.ncols), dtype=np.int16)

        self._temp_goal = None
        self.meta = {}

        self.obstacles = [] 

    def set_temporary_goal(self, rc):
        self._temp_goal = None if rc is None else (int(rc[0]), int(rc[1]))

    def in_bounds(self, r, c):
        return 0 <= r < self.nrows and 0 <= c < self.ncols

    def is_free(self, r, c):
        if not self.in_bounds(r, c):
            return False
        if self._temp_goal is not None and (int(r), int(c)) == self._temp_goal:
            return True
        return int(self.grid[int(r), int(c)]) == 0

    def set_cell(self, r, c, v):
        if self.in_bounds(int(r), int(c)):
            self.grid[int(r), int(c)] = int(v)

    def fill_rect(self, r0, c0, r1, c1, v):
        rmin, rmax = sorted((int(r0), int(r1)))
        cmin, cmax = sorted((int(c0), int(c1)))
        rmin = max(0, rmin); rmax = min(self.nrows - 1, rmax)
        cmin = max(0, cmin); cmax = min(self.ncols - 1, cmax)
        self.grid[rmin:rmax+1, cmin:cmax+1] = int(v)

    def cell_cost(self, r, c):
        if not self.in_bounds(r, c):
            return float("inf")
        v = int(self.grid[r, c])
        if v == 0:
            return 1.0
        if v == 1:
            return float("inf") 
        return float("inf")

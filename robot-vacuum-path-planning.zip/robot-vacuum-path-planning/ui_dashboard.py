import time
import pygame
import math

from planner_astar import astar
from planner_dijkstra import dijkstra
from planner_rrt import rrt
from planner_prm import prm

from ui_theme import BG, PANEL, TEXT, MUTED, BLUE, GREEN, YELLOW, RED, ROBOT_PINK
from ui_widgets import Panel, Button, draw_text


def xy_to_rc(map_grid, xy):
    x, y = xy
    cs = map_grid.cell_size
    c = int(x / cs)
    r = int(y / cs)
    r = max(0, min(map_grid.nrows - 1, r))
    c = max(0, min(map_grid.ncols - 1, c))
    return (r, c)


def is_xy_path(path):
    return bool(path) and (isinstance(path[0][0], float) or isinstance(path[0][1], float))


def draw_perry(screen, pos, size=26):
    x, y = pos
    s = size
    body = (0, 170, 160)
    bill = (235, 170, 70)
    brown = (120, 80, 40)
    black = (10, 10, 10)
    white = (245, 245, 245)

    pygame.draw.ellipse(screen, body, pygame.Rect(x - s, y - s * 0.55, s * 2.0, s * 1.1))
    pygame.draw.ellipse(screen, black, pygame.Rect(x - s, y - s * 0.55, s * 2.0, s * 1.1), 2)

    pygame.draw.ellipse(screen, bill, pygame.Rect(x - s * 0.35, y + s * 0.05, s * 0.7, s * 0.35))
    pygame.draw.ellipse(screen, black, pygame.Rect(x - s * 0.35, y + s * 0.05, s * 0.7, s * 0.35), 2)

    pygame.draw.circle(screen, white, (int(x - s * 0.35), int(y - s * 0.12)), int(s * 0.12))
    pygame.draw.circle(screen, white, (int(x + s * 0.35), int(y - s * 0.12)), int(s * 0.12))
    pygame.draw.circle(screen, black, (int(x - s * 0.35), int(y - s * 0.12)), int(s * 0.05))
    pygame.draw.circle(screen, black, (int(x + s * 0.35), int(y - s * 0.12)), int(s * 0.05))

    pygame.draw.rect(screen, brown, pygame.Rect(x - s * 0.55, y - s * 0.85, s * 1.1, s * 0.28), border_radius=6)
    pygame.draw.rect(screen, brown, pygame.Rect(x - s * 0.30, y - s * 1.05, s * 0.60, s * 0.26), border_radius=6)
    pygame.draw.rect(screen, black, pygame.Rect(x - s * 0.55, y - s * 0.85, s * 1.1, s * 0.28), 2, border_radius=6)
    pygame.draw.rect(screen, black, pygame.Rect(x - s * 0.30, y - s * 1.05, s * 0.60, s * 0.26), 2, border_radius=6)


def draw_marsupilami(screen, pos, size=26):
    x, y = pos
    s = size
    yellow = (250, 215, 70)
    black = (20, 20, 20)
    pink = (255, 120, 160)
    white = (245, 245, 245)

    pygame.draw.circle(screen, yellow, (x, y), int(s * 0.55))
    pygame.draw.circle(screen, black, (x, y), int(s * 0.55), 2)

    for dx, dy in [(-0.25, -0.15), (0.20, -0.20), (-0.05, 0.18)]:
        pygame.draw.circle(screen, black, (int(x + s * dx), int(y + s * dy)), int(s * 0.08))

    pygame.draw.circle(screen, white, (int(x - s * 0.18), int(y - s * 0.10)), int(s * 0.12))
    pygame.draw.circle(screen, white, (int(x + s * 0.18), int(y - s * 0.10)), int(s * 0.12))
    pygame.draw.circle(screen, black, (int(x - s * 0.18), int(y - s * 0.10)), int(s * 0.05))
    pygame.draw.circle(screen, black, (int(x + s * 0.18), int(y - s * 0.10)), int(s * 0.05))

    pygame.draw.circle(screen, pink, (int(x), int(y + s * 0.10)), int(s * 0.08))
    pygame.draw.circle(screen, black, (int(x), int(y + s * 0.10)), int(s * 0.08), 1)


def draw_robot_with_bow(screen, pos, radius):
    cx, cy = pos
    pygame.draw.circle(screen, ROBOT_PINK, (cx, cy), radius)
    pygame.draw.circle(screen, (0, 0, 0), (cx, cy), radius, 2)


def draw_grid_map(
    screen,
    grid,
    rect,
    robot_rc=None,
    goal_rc=None,
    path=None,
    cleaned=None,
    path_xy=None,
    cell_size=0.2
):
    rows, cols = grid.shape
    cell_w = rect.width / cols
    cell_h = rect.height / rows

    floor_a = (22, 24, 32)
    floor_b = (24, 27, 36)
    wall_a = (170, 135, 95)
    wall_b = (155, 122, 85)
    wall_ln = (110, 90, 65)

    obs_colors = {
        2: (235, 75, 90),
        3: (60, 210, 120),
        4: (170, 110, 220),
        5: (240, 165, 60),
        6: (80, 150, 255),
        8: (0, 0, 0),
    }

    pygame.draw.rect(screen, (18, 20, 26), rect, border_radius=12)

    for r in range(rows):
        for c in range(cols):
            x = rect.x + c * cell_w
            y = rect.y + r * cell_h
            cell = pygame.Rect(x, y, cell_w, cell_h)
            v = int(grid[r, c])

            if v == 0:
                col = floor_a if (r + c) % 2 == 0 else floor_b
                pygame.draw.rect(screen, col, cell)
            elif v == 1:
                col = wall_a if (r + c) % 2 == 0 else wall_b
                pygame.draw.rect(screen, col, cell)
                pygame.draw.rect(screen, wall_ln, cell, 1)
            elif v == 7:
                pygame.draw.rect(screen, (35, 38, 50), cell)
                pygame.draw.rect(screen, (0, 0, 0), cell, 1)
                draw_perry(screen, (int(cell.centerx), int(cell.centery)), size=max(16, int(min(cell_w, cell_h) * 0.62)))
            elif v == 8:
                pygame.draw.rect(screen, (35, 38, 50), cell)
                pygame.draw.rect(screen, (0, 0, 0), cell, 1)
                draw_marsupilami(screen, (int(cell.centerx), int(cell.centery)), size=max(16, int(min(cell_w, cell_h) * 0.62)))
            else:
                col = obs_colors.get(v, (200, 200, 200))
                pygame.draw.rect(screen, col, cell)
                pygame.draw.rect(screen, (0, 0, 0), cell, 1)


    if cleaned:
        overlay = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        for (rr, cc) in cleaned:
            ox = int(cc * cell_w)
            oy = int(rr * cell_h)
            pygame.draw.rect(overlay, (70, 160, 255, 70), pygame.Rect(ox, oy, int(cell_w), int(cell_h)))
        screen.blit(overlay, (rect.x, rect.y))


    if path_xy and len(path_xy) > 1:
        Wm = cols * cell_size
        Hm = rows * cell_size
        pts = []
        for (x, y) in path_xy:
            px = rect.x + (x / Wm) * rect.width
            py = rect.y + (y / Hm) * rect.height
            pts.append((px, py))
        pygame.draw.lines(screen, (160, 210, 255), False, pts, 2)


    elif path and len(path) > 1:
        pts = []
        for (rr, cc) in path:
            cx = rect.x + (cc + 0.5) * cell_w
            cy = rect.y + (rr + 0.5) * cell_h
            pts.append((cx, cy))
        pygame.draw.lines(screen, (160, 210, 255), False, pts, 2)


    if goal_rc is not None:
        gr, gc = goal_rc
        gx = rect.x + (gc + 0.5) * cell_w
        gy = rect.y + (gr + 0.5) * cell_h
        pygame.draw.circle(screen, (255, 255, 255), (int(gx), int(gy)), 6)
        pygame.draw.circle(screen, (0, 0, 0), (int(gx), int(gy)), 6, 2)


    if robot_rc is not None:
        rr, rc = robot_rc
        cx = rect.x + (rc + 0.5) * cell_w
        cy = rect.y + (rr + 0.5) * cell_h
        radius = max(10, int(min(cell_w, cell_h) * 0.9))
        draw_robot_with_bow(screen, (int(cx), int(cy)), radius)


def draw_comparison_chart(screen, rect, fonts, results):
    pygame.draw.rect(screen, (22, 24, 32), rect, border_radius=12)
    pygame.draw.rect(screen, (55, 60, 75), rect, width=1, border_radius=12)
    title = fonts["h2"].render("Karşılaştırma Grafiği (Süre)", True, TEXT)
    screen.blit(title, (rect.x + 12, rect.y + 10))

    chart = rect.inflate(-24, -44)
    chart.y += 32

    algos = ["A*", "Dijkstra", "RRT", "PRM"]
    colors = {"A*": BLUE, "Dijkstra": RED, "RRT": GREEN, "PRM": YELLOW}
    key = "time_ms"
    max_v = max(1e-9, max(results[a][key] for a in algos))

    pygame.draw.line(screen, (55, 60, 75), (chart.x, chart.bottom), (chart.right, chart.bottom), 1)

    group_w = chart.width / len(algos)
    bar_w = min(26, group_w * 0.35)

    for i, algo in enumerate(algos):
        v = results[algo][key]
        h = int((v / max_v) * (chart.height - 30))
        x = int(chart.x + i * group_w + group_w * 0.5 - bar_w * 0.5)
        y = chart.bottom - h
        pygame.draw.rect(screen, colors[algo], pygame.Rect(x, y, int(bar_w), h), border_radius=6)

        label = fonts["small"].render(algo, True, MUTED)
        screen.blit(label, (int(chart.x + i * group_w + group_w * 0.5 - label.get_width() / 2), chart.bottom + 6))


def build_dashboard_layout(W, H):
    pad = 18
    topbar_h = 44
    metrics_w = 380
    left_w = W - metrics_w - pad * 3

    y0 = pad + topbar_h
    usable_h = H - pad * 2 - topbar_h
    row_h = (usable_h - pad) / 2
    col_w = (left_w - pad) / 2

    p1 = pygame.Rect(pad, y0, col_w, row_h)
    p2 = pygame.Rect(pad + col_w + pad, y0, col_w, row_h)
    p3 = pygame.Rect(pad, y0 + row_h + pad, col_w, row_h)
    p4 = pygame.Rect(pad + col_w + pad, y0 + row_h + pad, col_w, row_h)
    metrics = pygame.Rect(pad * 2 + left_w, y0, metrics_w, usable_h)
    return p1, p2, p3, p4, metrics, topbar_h


class Dashboard:
    def __init__(self, fonts, map_grid, start_rc):
        self.fonts = fonts
        self.map_grid = map_grid

        self.start_rc = start_rc

        self.goal_rc = self._nearest_free(
            (self.map_grid.nrows - 2, self.map_grid.ncols - 2),
            max_radius=20
        )

        self.results = {
            "A*": {"distance": 0.0, "time_ms": 0.0, "collisions": 0.0, "near_miss": 0, "smoothness": 0.0},
            "Dijkstra": {"distance": 0.0, "time_ms": 0.0, "collisions": 0.0, "near_miss": 0, "smoothness": 0.0},
            "RRT": {"distance": 0.0, "time_ms": 0.0, "collisions": 0.0, "near_miss": 0, "smoothness": 0.0},
            "PRM": {"distance": 0.0, "time_ms": 0.0, "collisions": 0.0, "near_miss": 0.0, "smoothness": 0.0},
        }

        self.sim = {}
        for key in ["A*", "Dijkstra", "RRT", "PRM"]:
            self.sim[key] = {
                "running": False,
                "speed": 1.0,
                "path": [],
                "path_xy": None,   
                "step": 0,
                "robot": self.start_rc,
                "cleaned": set(),
                "accum": 0.0,
                "status": "READY"
            }

        self.buttons = {}
        self._W, self._H = 1400, 860

    def _path_distance_m(self, path):
        if not path or len(path) < 2:
            return 0.0
        dist = 0.0
        cs = self.map_grid.cell_size
        for i in range(1, len(path)):
            r0, c0 = path[i - 1]
            r1, c1 = path[i]
            dx = (c1 - c0) * cs
            dy = (r1 - r0) * cs
            dist += math.hypot(dx, dy)
        return dist

    def _panel_inner_rect(self, panel_rect):
        inner = panel_rect.inflate(-26, -120)
        inner.y += 36
        return inner

    def _nearest_free(self, rc, max_radius=12):
        if rc is None:
            return None
        r0, c0 = rc
        if int(self.map_grid.grid[r0, c0]) == 0:
            return (r0, c0)

        for rad in range(1, max_radius + 1):
            for dr in range(-rad, rad + 1):
                for dc in range(-rad, rad + 1):
                    if abs(dr) != rad and abs(dc) != rad:
                        continue
                    r = r0 + dr
                    c = c0 + dc
                    if 0 <= r < self.map_grid.nrows and 0 <= c < self.map_grid.ncols:
                        if int(self.map_grid.grid[r, c]) == 0:
                            return (r, c)
        return None

    def _find_centroid_of_value(self, value):
        ys, xs = (self.map_grid.grid == value).nonzero()
        if len(ys) == 0:
            return None
        r = int(round(float(ys.mean())))
        c = int(round(float(xs.mean())))
        return (r, c)

    def _plan_multi_stage(self, algo_key, waypoints):
        if algo_key == "A*":
            planner = astar
        elif algo_key == "Dijkstra":
            planner = dijkstra
        elif algo_key == "RRT":
            planner = rrt
        elif algo_key == "PRM":
            planner = prm
        else:
            return None

        full = []
        cur = self.start_rc

        for g in waypoints:
            seg = planner(self.map_grid, cur, g)
            if not seg or len(seg) < 2:
                return None
            if full:
                full.extend(seg[1:])
            else:
                full.extend(seg)
            cur = g

        return full


    def _compute_collision_ratio(self, path):
        if not path or len(path) < 2:
            return 0.0

        collisions = 0
        steps = len(path) - 1

        for (r, c) in path:
            for dr, dc in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                nr, nc = r + dr, c + dc
                if 0 <= nr < self.map_grid.nrows and 0 <= nc < self.map_grid.ncols:
                    if int(self.map_grid.grid[nr, nc]) != 0:
                        collisions += 1
                        break

        return collisions / max(1, steps)


    def _compute_smoothness(self, path):
        if not path or len(path) < 3:
            return 0.0

        angles = []
        for i in range(1, len(path) - 1):
            r0, c0 = path[i - 1]
            r1, c1 = path[i]
            r2, c2 = path[i + 1]

            v1 = (r1 - r0, c1 - c0)
            v2 = (r2 - r1, c2 - c1)

            dot = v1[0] * v2[0] + v1[1] * v2[1]
            mag1 = math.hypot(v1[0], v1[1])
            mag2 = math.hypot(v2[0], v2[1])
            if mag1 == 0 or mag2 == 0:
                continue

            cos_theta = max(-1.0, min(1.0, dot / (mag1 * mag2)))
            angle = math.acos(cos_theta)
            angles.append(angle)

        if not angles:
            return 0.0

        mean = sum(angles) / len(angles)
        var = sum((a - mean) ** 2 for a in angles) / len(angles)
        return var

    def _run_planner(self, algo_key):
        s = self.sim[algo_key]
        s["robot"] = self.start_rc
        s["cleaned"] = {self.start_rc}
        s["step"] = 0
        s["accum"] = 0.0
        s["path_xy"] = None

        t0 = time.perf_counter()

        green_center = self._find_centroid_of_value(3)
        purple_center = self._find_centroid_of_value(4)

        wp_green = self._nearest_free(green_center, max_radius=35) if green_center else None
        wp_purple = self._nearest_free(purple_center, max_radius=35) if purple_center else None

        waypoints = []
        if wp_green is not None:
            waypoints.append(wp_green)
        if wp_purple is not None:
            waypoints.append(wp_purple)
        if self.goal_rc is not None:
            waypoints.append(self.goal_rc)

        path = self._plan_multi_stage(algo_key, waypoints)


        if is_xy_path(path):
            s["path_xy"] = path[:]  


            path = [xy_to_rc(self.map_grid, p) for p in path]

        t1 = time.perf_counter()
        self.results[algo_key]["time_ms"] = (t1 - t0) * 1000.0

        if not path or len(path) < 2:
            s["path"] = []
            s["path_xy"] = None
            self.results[algo_key]["distance"] = 0.0
            self.results[algo_key]["collisions"] = 0.0
            self.results[algo_key]["smoothness"] = 0.0
            s["running"] = False
            s["status"] = "NO PATH"
            return

        s["path"] = path
        self.results[algo_key]["distance"] = self._path_distance_m(path)
        self.results[algo_key]["collisions"] = self._compute_collision_ratio(path)
        self.results[algo_key]["smoothness"] = self._compute_smoothness(path)

        s["running"] = True
        s["status"] = "RUNNING"

    def _stop_algo(self, algo_key):
        s = self.sim[algo_key]
        s["running"] = False
        if s["status"] == "RUNNING":
            s["status"] = "READY"

    def _reset_algo(self, algo_key):
        s = self.sim[algo_key]
        s["running"] = False
        s["path"] = []
        s["path_xy"] = None
        s["step"] = 0
        s["robot"] = self.start_rc
        s["cleaned"] = set()
        s["accum"] = 0.0
        s["status"] = "READY"
        self.results[algo_key] = {"distance": 0.0, "time_ms": 0.0, "collisions": 0.0, "near_miss": 0, "smoothness": 0.0}

    def handle_event(self, event):
        for btn in self.buttons.values():
            btn.handle_event(event)

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for (algo, action), btn in self.buttons.items():
                if not btn.rect.collidepoint(event.pos):
                    continue
                if action == "start":
                    self._run_planner(algo)
                elif action == "stop":
                    self._stop_algo(algo)
                elif action == "reset":
                    self._reset_algo(algo)
                elif action.startswith("speed_"):
                    sp = action.split("_", 1)[1]
                    self.sim[algo]["speed"] = {"0.5x": 0.5, "1x": 1.0, "2x": 2.0, "3x": 3.0}.get(sp, 1.0)
                return

    def update(self, dt):
        for algo_key, s in self.sim.items():
            if not s["running"] or not s["path"]:
                continue
            steps_per_sec = 6.0 * s["speed"]
            s["accum"] += steps_per_sec * dt
            while s["accum"] >= 1.0:
                s["accum"] -= 1.0
                if s["step"] >= len(s["path"]) - 1:
                    s["running"] = False
                    s["status"] = "DONE"
                    break
                s["step"] += 1
                s["robot"] = s["path"][s["step"]]
                s["cleaned"].add(s["robot"])

    def draw(self, screen, W, H):
        self._W, self._H = W, H

        screen.fill(BG)
        p1, p2, p3, p4, metrics_rect, topbar_h = build_dashboard_layout(W, H)
        pygame.draw.rect(screen, (16, 18, 24), pygame.Rect(0, 0, W, topbar_h))
        title = self.fonts["h2"].render("Robot Vacuum Simulation - Independent Control", True, TEXT)
        screen.blit(title, (18, 12))

        panels = [
            (Panel(p1, "A*", BLUE), "A*"),
            (Panel(p2, "Dijkstra", RED), "Dijkstra"),
            (Panel(p3, "RRT", GREEN), "RRT"),
            (Panel(p4, "PRM", YELLOW), "PRM"),
        ]
        self.buttons = {}

        for panel, key in panels:
            panel.draw_frame(screen, self.fonts, PANEL)

            inner = panel.rect.inflate(-26, -120)
            inner.y += 36

            s = self.sim[key]
            draw_grid_map(
                screen,
                self.map_grid.grid,
                inner,
                robot_rc=s["robot"],
                goal_rc=self.goal_rc,
                path=s["path"],
                cleaned=s["cleaned"],
                path_xy=s.get("path_xy"),
                cell_size=self.map_grid.cell_size
            )

            st = self.fonts["small"].render(f"Status: {s['status']}", True, MUTED)
            screen.blit(st, (panel.rect.x + 14, panel.rect.y + 34))


            if key in ["RRT", "PRM"]:
                hx = panel.rect.x + 14
                hy = panel.rect.y + 58
                for i, sp in enumerate(["0.5x", "1x", "2x", "3x"]):
                    sb = Button((hx + i * 58, hy, 52, 28), sp, (45, 50, 65))
                    self.buttons[(key, f"speed_{sp}")] = sb
                    sb.draw(screen, self.fonts["small"])


            bx = panel.rect.x + 14
            by = panel.rect.bottom - 52
            b_w, b_h, gap = 86, 34, 10

            b1 = Button((bx, by, b_w, b_h), "BASLAT", (40, 170, 110))
            b2 = Button((bx + b_w + gap, by, b_w, b_h), "DURDUR", (200, 150, 60))
            b3 = Button((bx + (b_w + gap) * 2, by, b_w, b_h), "SIFIRLA", (210, 80, 80))

            self.buttons[(key, "start")] = b1
            self.buttons[(key, "stop")] = b2
            self.buttons[(key, "reset")] = b3

            b1.draw(screen, self.fonts["small"])
            b2.draw(screen, self.fonts["small"])
            b3.draw(screen, self.fonts["small"])


            if key not in ["RRT", "PRM"]:
                speed_y = by + b_h + 10
                for i, sp in enumerate(["0.5x", "1x", "2x", "3x"]):
                    sb = Button((bx + i * 58, speed_y, 52, 28), sp, (45, 50, 65))
                    self.buttons[(key, f"speed_{sp}")] = sb
                    sb.draw(screen, self.fonts["small"])

        pygame.draw.rect(screen, PANEL, metrics_rect, border_radius=16)
        pygame.draw.rect(screen, (55, 60, 75), metrics_rect, width=1, border_radius=16)
        mtitle = self.fonts["title"].render("METRICS", True, TEXT)
        screen.blit(mtitle, (metrics_rect.x + 16, metrics_rect.y + 14))

        y = metrics_rect.y + 58
        for name, color in [("A*", BLUE), ("Dijkstra", RED), ("RRT", GREEN), ("PRM", YELLOW)]:
            txt = self.fonts["h2"].render(name, True, color)
            screen.blit(txt, (metrics_rect.x + 16, y))
            y += 24
            r = self.results[name]

            draw_text(screen, f"Yol: {r['distance']:.2f} m", (metrics_rect.x + 16, y), self.fonts["small"], MUTED); y += 18
            draw_text(screen, f"Süre: {r['time_ms']:.2f} ms", (metrics_rect.x + 16, y), self.fonts["small"], MUTED); y += 18
            draw_text(screen, f"Çarpışma Oranı (C): {r['collisions']:.3f}", (metrics_rect.x + 16, y), self.fonts["small"], MUTED); y += 18
            draw_text(screen, f"Yol Düzgünlüğü (S): {r['smoothness']:.4f}", (metrics_rect.x + 16, y), self.fonts["small"], MUTED); y += 18

            pygame.draw.line(screen, (55, 60, 75), (metrics_rect.x + 16, y), (metrics_rect.right - 16, y), 1)
            y += 14

        chart_rect = pygame.Rect(
            metrics_rect.x + 14,
            metrics_rect.y + int(metrics_rect.height * 0.58),
            metrics_rect.width - 28,
            int(metrics_rect.height * 0.38) - 18
        )
        draw_comparison_chart(screen, chart_rect, self.fonts, self.results)

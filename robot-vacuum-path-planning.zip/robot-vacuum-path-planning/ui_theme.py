import pygame

BG     = (12, 14, 18)
PANEL  = (22, 24, 32)
TEXT   = (235, 235, 240)
MUTED  = (160, 165, 180)

BLUE   = (80, 160, 255)
GREEN  = (45, 200, 120)
YELLOW = (230, 180, 60)
RED    = (240, 80, 80)

ROBOT_PINK = (255, 120, 200)

def get_fonts():
    pygame.font.init()
    return {
        "title": pygame.font.SysFont("Segoe UI", 26, bold=True),
        "h2":    pygame.font.SysFont("Segoe UI", 18, bold=True),
        "small": pygame.font.SysFont("Segoe UI", 14, bold=False),
    }

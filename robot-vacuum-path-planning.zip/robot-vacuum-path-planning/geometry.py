import math

def dist_sq(a, b):
    return (a[0]-b[0])**2 + (a[1]-b[1])**2

def distance(a, b):
    return math.sqrt(dist_sq(a, b))

def ccw(A, B, C):
    return (C[1]-A[1]) * (B[0]-A[0]) > (B[1]-A[1]) * (C[0]-A[0])

def intersect(A, B, C, D):
    return ccw(A,C,D) != ccw(B,C,D) and ccw(A,B,C) != ccw(A,B,D)

def segment_intersects_obstacle(p1, p2, obstacles):
    for poly in obstacles:
        n = len(poly)
        for i in range(n):
            u = poly[i]
            v = poly[(i+1)%n]

            if p1 == u or p1 == v or p2 == u or p2 == v:
                continue

            if intersect(p1, p2, u, v):
                return True
    return False

def build_visibility_graph(start, goal, obstacles):
    nodes = [start, goal]
    for poly in obstacles:
        for pt in poly:
            nodes.append(pt)

    unique_nodes = []
    seen = set()
    for n in nodes:
        if n not in seen:
            unique_nodes.append(n)
            seen.add(n)
    nodes = unique_nodes

    graph = {node: [] for node in nodes}

    for i in range(len(nodes)):
        for j in range(i + 1, len(nodes)):
            u = nodes[i]
            v = nodes[j]

            if not segment_intersects_obstacle(u, v, obstacles):
                d = distance(u, v)
                graph[u].append((v, d))
                graph[v].append((u, d))

    return graph

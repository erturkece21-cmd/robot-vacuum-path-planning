from heapq import heappush, heappop
import geometry  
import math

def reconstruct_path(parent, current):
    path = [current]
    while current in parent:
        current = parent[current]
        path.append(current)
    path.reverse()
    return [(int(r), int(c)) for r, c in path]

def dijkstra(map_grid, start, goal):
    start = (float(start[0]), float(start[1]))
    goal  = (float(goal[0]),  float(goal[1]))


    graph = geometry.build_visibility_graph(start, goal, map_grid.obstacles)

    pq = [(0, start)]
    dist = {node: float('inf') for node in graph}
    dist[start] = 0
    parent = {}
    visited = set()

    while pq:
        d, cur = heappop(pq)

        if cur == goal:
            return reconstruct_path(parent, cur)

        if cur in visited:
            continue
        visited.add(cur)


        for neighbor, weight in graph[cur]:
            if neighbor in visited:
                continue

            new_dist = d + weight
            if new_dist < dist[neighbor]:
                dist[neighbor] = new_dist
                parent[neighbor] = cur
                heappush(pq, (new_dist, neighbor))

    return None

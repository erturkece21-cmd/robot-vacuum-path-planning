import math
import random
import heapq
import geometry 

def euclid(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])

def is_collision_free(p1, p2, obstacles):

    return not geometry.segment_intersects_obstacle(p1, p2, obstacles)

def prm(map_grid, start, goal, n_samples=100, connect_radius=15.0):
    start = (float(start[0]), float(start[1]))
    goal  = (float(goal[0]),  float(goal[1]))


    nodes = [start, goal]
    for _ in range(n_samples):

        rand_pt = (random.uniform(0, map_grid.nrows), random.uniform(0, map_grid.ncols))


        if map_grid.is_free(rand_pt[0], rand_pt[1]):
            nodes.append(rand_pt)


    adj = {node: [] for node in nodes}

    for i, u in enumerate(nodes):
        for j, v in enumerate(nodes):
            if i == j: continue

            d = euclid(u, v)
            if d <= connect_radius:

                if is_collision_free(u, v, map_grid.obstacles):
                    adj[u].append((v, d))


    pq = [(0, start)]
    dist = {node: float('inf') for node in nodes}
    dist[start] = 0
    parent = {}

    while pq:
        d, u = heapq.heappop(pq)

        if u == goal:

            path = []
            curr = goal
            while curr in parent:
                path.append((int(curr[0]), int(curr[1])))
                curr = parent[curr]
            path.append((int(start[0]), int(start[1])))
            path.reverse()
            return path

        if d > dist[u]: continue

        for v, weight in adj[u]:
            if dist[u] + weight < dist[v]:
                dist[v] = dist[u] + weight
                parent[v] = u
                heapq.heappush(pq, (dist[v], v))

    return None

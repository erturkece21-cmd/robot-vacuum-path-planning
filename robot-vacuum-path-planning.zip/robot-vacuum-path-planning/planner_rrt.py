import math
import random
import geometry 

def euclid(a, b):
    return math.hypot(a[0] - b[0], a[1] - b[1])

def steer(from_node, to_node, step_size):

    dist = euclid(from_node, to_node)
    if dist < step_size:
        return to_node
    else:
        theta = math.atan2(to_node[1] - from_node[1], to_node[0] - from_node[0])
        return (from_node[0] + step_size * math.cos(theta),
                from_node[1] + step_size * math.sin(theta))

def rrt(map_grid, start, goal, max_iter=2000, step_size=1.0, goal_radius=1.5):

    start = (float(start[0]), float(start[1]))
    goal  = (float(goal[0]),  float(goal[1]))

    nodes = [start]
    parents = {start: None}

    for _ in range(max_iter):

        if random.random() < 0.1:
            rand_node = goal
        else:

            rand_node = (random.uniform(0, map_grid.nrows), random.uniform(0, map_grid.ncols))


        nearest_node = min(nodes, key=lambda n: euclid(n, rand_node))


        new_node = steer(nearest_node, rand_node, step_size)


        if not geometry.segment_intersects_obstacle(nearest_node, new_node, map_grid.obstacles):
            nodes.append(new_node)
            parents[new_node] = nearest_node


            if euclid(new_node, goal) < goal_radius:
                if not geometry.segment_intersects_obstacle(new_node, goal, map_grid.obstacles):
                    parents[goal] = new_node


                    path = []
                    curr = goal
                    while curr is not None:
                        path.append((int(curr[0]), int(curr[1])))
                        curr = parents[curr]
                    path.reverse()
                    return path
    return None

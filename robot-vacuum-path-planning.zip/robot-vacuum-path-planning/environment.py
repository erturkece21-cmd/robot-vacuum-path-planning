from grid_map import MapGrid

def add_rect_obstacle(m, r1, c1, r2, c2, val=1):
    m.fill_rect(r1, c1, r2, c2, val)

    top = min(r1, r2)
    bottom = max(r1, r2)
    left = min(c1, c2)
    right = max(c1, c2)

    poly = [
        (top - 0.6, left - 0.6), 
        (top - 0.6, right + 0.6),
        (bottom + 0.6, right + 0.6), 
        (bottom + 0.6, left - 0.6)
    ]
    m.obstacles.append(poly)

def build_environment():
    m = MapGrid(width_m=12.0, height_m=9.0, cell_size=0.2)
    R, C = m.nrows, m.ncols

    add_rect_obstacle(m, 0, 0, 0, C - 1)      
    add_rect_obstacle(m, R - 1, 0, R - 1, C - 1) 
    add_rect_obstacle(m, 0, 0, R - 1, 0)      
    add_rect_obstacle(m, 0, C - 1, R - 1, C - 1) 

    r_mid = int(R * 0.45)
    c_right = int(C * 0.72)
    gap1 = int(C * 0.35)
    gap2 = int(C * 0.62)

    add_rect_obstacle(m, r_mid, 1, r_mid, gap1 - 2)
    add_rect_obstacle(m, r_mid, gap1 + 2, r_mid, gap2 - 2)
    add_rect_obstacle(m, r_mid, c_right, R - 2, c_right)

    r_low = int(R * 0.72)
    add_rect_obstacle(m, r_low, c_right, r_low, int(C * 0.88))

    add_rect_obstacle(m, int(R * 0.62), int(C * 0.40), int(R * 0.74), int(C * 0.56), 3)

    start_rc = (int(R * 0.18), int(C * 0.08))
    marsu_rc = (int(R * 0.22), int(C * 0.86))
    yellow_rc = (int(R * 0.78), int(C * 0.86))
    perry_rc = (int(R * 0.78), int(C * 0.18))

    m.set_cell(*marsu_rc, 8)
    m.set_cell(*yellow_rc, 5)
    m.set_cell(*perry_rc, 7)

    m.meta = {
        "targets": {"marsu": marsu_rc, "yellow": yellow_rc, "perry": perry_rc},
        "doors": {},
        "walls": {}
    }

    return m, start_rc

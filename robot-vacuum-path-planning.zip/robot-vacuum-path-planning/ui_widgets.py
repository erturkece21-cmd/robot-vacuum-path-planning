import pygame


class Button:
    def __init__(self, rect, text, color):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.color = color
        self.hover = False

    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            self.hover = self.rect.collidepoint(event.pos)

    def draw(self, screen, font):
        col = tuple(min(255, c + 20) for c in self.color) if self.hover else self.color
        pygame.draw.rect(screen, col, self.rect, border_radius=10)
        pygame.draw.rect(screen, (0, 0, 0), self.rect, 2, border_radius=10)
        surf = font.render(self.text, True, (0, 0, 0))
        screen.blit(
            surf,
            (
                self.rect.centerx - surf.get_width() // 2,
                self.rect.centery - surf.get_height() // 2
            )
        )


class Panel:
    def __init__(self, rect, title, accent):
        self.rect = pygame.Rect(rect)
        self.title = title
        self.accent = accent

    def draw_frame(self, screen, fonts, fill_color):
        pygame.draw.rect(screen, fill_color, self.rect, border_radius=16)
        pygame.draw.rect(screen, (55, 60, 75), self.rect, 1, border_radius=16)

        pygame.draw.rect(
            screen,
            self.accent,
            pygame.Rect(self.rect.x, self.rect.y, self.rect.width, 6),
            border_radius=16
        )

        t = fonts["h2"].render(self.title, True, (240, 242, 247))
        screen.blit(t, (self.rect.x + 12, self.rect.y + 10))


def draw_text(screen, text, pos, font, color):
    s = font.render(text, True, color)
    screen.blit(s, pos)


def draw_multiline_text(screen, text, pos, font, color, line_gap=2):

    x, y = pos
    for line in str(text).split("\n"):
        s = font.render(line, True, color)
        screen.blit(s, (x, y))
        y += s.get_height() + line_gap
    return y  


def draw_value_row(screen, label, value, pos, font, color, fmt=None):

    if fmt and isinstance(value, (int, float)):
        txt = f"{label}: {value:{fmt}}"
    else:
        txt = f"{label}: {value}"
    draw_text(screen, txt, pos, font, color)

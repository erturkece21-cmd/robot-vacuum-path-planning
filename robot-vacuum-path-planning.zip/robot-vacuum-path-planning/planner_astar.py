from heapq import heappush, heappop
import geometry 
import math

def heuristic(a, b):

    return math.hypot(a[0] - b[0], a[1] - b[1])

def reconstruct_path(came_from, current):
    path = [current]
    while current in came_from:
        current = came_from[current]
        path.append(current)
    path.reverse()

    return [(int(r), int(c)) for r, c in path]

def astar(map_grid, start, goal):

    start = (float(start[0]), float(start[1]))
    goal  = (float(goal[0]),  float(goal[1]))


    graph = geometry.build_visibility_graph(start, goal, map_grid.obstacles)

    open_set = []
    heappush(open_set, (0, start))

    came_from = {}
    g_score = {node: float('inf') for node in graph}
    g_score[start] = 0

    visited = set()

    while open_set:
        _, current = heappop(open_set)

        if current == goal:
            return reconstruct_path(came_from, current)

        if current in visited:
            continue
        visited.add(current)


        for neighbor, dist in graph[current]:
            tentative_g = g_score[current] + dist

            if tentative_g < g_score.get(neighbor, float('inf')):
                came_from[neighbor] = current
                g_score[neighbor] = tentative_g
                f = tentative_g + heuristic(neighbor, goal)
                heappush(open_set, (f, neighbor))

    return None
